// Mobile menu toggle
    const mobileBtn = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileBtn && mobileMenu) {
      mobileBtn.addEventListener('click', () => {
        const expanded = mobileBtn.getAttribute('aria-expanded') === 'true';
        mobileBtn.setAttribute('aria-expanded', String(!expanded));
        if (mobileMenu.style.display === 'block') {
          mobileMenu.style.display = 'none'; mobileMenu.setAttribute('aria-hidden','true');
        } else {
          mobileMenu.style.display = 'block'; mobileMenu.setAttribute('aria-hidden','false');
        }
      });
    }

    // Back to top
    const backBtn = document.getElementById('back-to-top');
    window.addEventListener('scroll', () => {
      if (window.pageYOffset > 300) backBtn.classList.add('show'); else backBtn.classList.remove('show');
    });
    backBtn.addEventListener('click', () => window.scrollTo({top:0,behavior:'smooth'}));

    // Toggle monthly/yearly
    const toggleMonthly = document.getElementById('toggle-monthly');
    const toggleYearly = document.getElementById('toggle-yearly');
    function showMonthly(){
      toggleMonthly.classList.add('active'); toggleMonthly.setAttribute('aria-selected','true');
      toggleYearly.classList.remove('active'); toggleYearly.setAttribute('aria-selected','false');
      document.querySelectorAll('.monthly-price').forEach(e=>e.style.display='inline-block');
      document.querySelectorAll('.monthly-period').forEach(e=>e.style.display='inline-block');
      document.querySelectorAll('.yearly-price').forEach(e=>e.style.display='none');
      document.querySelectorAll('.yearly-period').forEach(e=>e.style.display='none');
      document.querySelectorAll('.yearly-save').forEach(e=>e.style.display='none');
    }
    function showYearly(){
      toggleYearly.classList.add('active'); toggleYearly.setAttribute('aria-selected','true');
      toggleMonthly.classList.remove('active'); toggleMonthly.setAttribute('aria-selected','false');
      document.querySelectorAll('.monthly-price').forEach(e=>e.style.display='none');
      document.querySelectorAll('.monthly-period').forEach(e=>e.style.display='none');
      document.querySelectorAll('.yearly-price').forEach(e=>e.style.display='inline-block');
      document.querySelectorAll('.yearly-period').forEach(e=>e.style.display='inline-block');
      document.querySelectorAll('.yearly-save').forEach(e=>e.style.display='block');
    }
    if (toggleMonthly && toggleYearly) {
      toggleMonthly.addEventListener('click', showMonthly);
      toggleYearly.addEventListener('click', showYearly);
    }

    // FAQ toggle
    document.querySelectorAll('.faq .question').forEach(q=>{
      q.addEventListener('click', ()=>{
        const ans = q.nextElementSibling;
        const icon = q.querySelector('i');
        if (ans.style.display === 'block') { ans.style.display = 'none'; icon.classList.remove('fa-chevron-up'); icon.classList.add('fa-chevron-down'); }
        else { ans.style.display = 'block'; icon.classList.remove('fa-chevron-down'); icon.classList.add('fa-chevron-up'); }
      });
    });

    // Form submission (demo)
    const membershipForm = document.getElementById('membership-form');
    if (membershipForm) {
      membershipForm.addEventListener('submit', function(e){
        e.preventDefault();
        const name = document.getElementById('quick-name').value.trim();
        const email = document.getElementById('quick-email').value.trim();
        const phone = document.getElementById('quick-phone').value.trim();
        if (name && email && phone){
          alert('Terima kasih! Formulir pendaftaran Anda telah dikirim. Tim Foreword Library akan menghubungi Anda dalam 24 jam.');
          this.reset();
        } else {
          alert('Harap isi semua field yang wajib diisi.');
        }
      });
    }

    // Package choose buttons
    document.querySelectorAll('[data-package]').forEach(btn=>{
      btn.addEventListener('click', ()=> {
        const pkg = btn.dataset.package || btn.closest('.package-card')?.querySelector('h3')?.textContent;
        alert('Anda telah memilih paket ' + pkg + '. Anda akan diarahkan ke halaman pembayaran (simulasi).');
      });
    });

    // Fade-in elements on scroll
    const fadeEls = document.querySelectorAll('.fade-in');
    const io = new IntersectionObserver(entries=>{
      entries.forEach(entry=>{
        if(entry.isIntersecting){
          entry.target.classList.add('visible');
          io.unobserve(entry.target);
        }
      });
    }, {threshold: 0.12});
    fadeEls.forEach(el=>io.observe(el));

    // Accessibility: hide mobile menu on resize to desktop
    window.addEventListener('resize', ()=> {
      if(window.innerWidth >= 1024 && mobileMenu){
        mobileMenu.style.display = 'none';
        if (mobileBtn) mobileBtn.setAttribute('aria-expanded','false');
      }
    });