// Mobile menu toggle
    const mobileBtn = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');

    mobileBtn.addEventListener('click', () => {
      const expanded = mobileBtn.getAttribute('aria-expanded') === 'true';
      mobileBtn.setAttribute('aria-expanded', String(!expanded));
      if (mobileMenu.style.display === 'block') {
        mobileMenu.style.display = 'none';
        mobileMenu.setAttribute('aria-hidden','true');
      } else {
        mobileMenu.style.display = 'block';
        mobileMenu.setAttribute('aria-hidden','false');
      }
    });

    // Hide mobile menu when link clicked (delegation)
    mobileMenu.addEventListener('click', (e) => {
      if (e.target.tagName === 'A') {
        mobileMenu.style.display = 'none';
        mobileBtn.setAttribute('aria-expanded','false');
      }
    });

    // Back to top
    const backBtn = document.getElementById('back-to-top');
    window.addEventListener('scroll', () => {
      if (window.pageYOffset > 300) {
        backBtn.classList.add('show');
      } else {
        backBtn.classList.remove('show');
      }
    });
    backBtn.addEventListener('click', () => window.scrollTo({top:0,behavior:'smooth'}));

    // Small hover effect for team cards (for devices with hover)
    document.querySelectorAll('.team-card').forEach(card => {
      card.addEventListener('mouseenter', () => {
        card.style.transform = 'translateY(-8px)';
      });
      card.addEventListener('mouseleave', () => {
        card.style.transform = '';
      });
    });

    // Fade-in on scroll for elements with class "fade-in" (progressive reveal)
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = 1;
          entry.target.style.transform = 'translateY(0)';
          io.unobserve(entry.target);
        }
      });
    }, {root:null,rootMargin:'0px',threshold:0.12});

    document.querySelectorAll('.card, .value-card, .team-card, .testimonial').forEach(el => {
      el.style.opacity = 0;
      el.style.transform = 'translateY(18px)';
      el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
      io.observe(el);
    });

    // Accessibility: close mobile menu on resize to desktop
    window.addEventListener('resize', () => {
      if (window.innerWidth >= 1024) {
        mobileMenu.style.display = 'none';
        mobileBtn.setAttribute('aria-expanded','false');
      }
    });

